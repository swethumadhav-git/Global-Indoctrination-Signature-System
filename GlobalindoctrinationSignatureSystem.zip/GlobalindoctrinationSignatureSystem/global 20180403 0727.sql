-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.5.22


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema indoctrinationdb
--

CREATE DATABASE IF NOT EXISTS indoctrinationdb;
USE indoctrinationdb;

--
-- Definition of table `admintl`
--

DROP TABLE IF EXISTS `admintl`;
CREATE TABLE `admintl` (
  `adminid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `emailid` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `mobaileNo` varchar(45) NOT NULL,
  `status` varchar(45) NOT NULL,
  PRIMARY KEY (`adminid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admintl`
--

/*!40000 ALTER TABLE `admintl` DISABLE KEYS */;
INSERT INTO `admintl` (`adminid`,`name`,`emailid`,`password`,`mobaileNo`,`status`) VALUES 
 (1,'SWETHUMADHAV','admin@gmail.com','12345','123','active');
/*!40000 ALTER TABLE `admintl` ENABLE KEYS */;


--
-- Definition of table `coursetl`
--

DROP TABLE IF EXISTS `coursetl`;
CREATE TABLE `coursetl` (
  `courseId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `courseName` varchar(100) NOT NULL,
  `courseDescription` varchar(1000) NOT NULL,
  `courseSyllabus` varchar(100) NOT NULL,
  `courseDuration` varchar(45) NOT NULL,
  `amount` float NOT NULL,
  `discount` float NOT NULL,
  `cateType` varchar(100) NOT NULL,
  PRIMARY KEY (`courseId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coursetl`
--

/*!40000 ALTER TABLE `coursetl` DISABLE KEYS */;
INSERT INTO `coursetl` (`courseId`,`courseName`,`courseDescription`,`courseSyllabus`,`courseDuration`,`amount`,`discount`,`cateType`) VALUES 
 (5,'Algorithms','Design Algorithoms','soon you will get','1 month',2000,0,'design'),
 (6,'Big data','Maintain data on Data warehouse','---','3 months',5000,0,'Data management');
/*!40000 ALTER TABLE `coursetl` ENABLE KEYS */;


--
-- Definition of table `coursevideostl`
--

DROP TABLE IF EXISTS `coursevideostl`;
CREATE TABLE `coursevideostl` (
  `coursevId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `courseId` int(10) unsigned NOT NULL,
  `videoName` varchar(60) NOT NULL,
  PRIMARY KEY (`coursevId`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coursevideostl`
--

/*!40000 ALTER TABLE `coursevideostl` DISABLE KEYS */;
INSERT INTO `coursevideostl` (`coursevId`,`courseId`,`videoName`) VALUES 
 (1,1,'jai.mp4'),
 (2,2,'jai.mp4'),
 (3,1,'jai.mp4'),
 (4,2,'jai.mp4'),
 (5,3,'jai.mp4'),
 (6,1,'jai.mp4'),
 (7,5,'jai.mp4'),
 (8,5,'jai.mp4'),
 (9,5,'jai.mp4'),
 (10,5,'jai.mp4'),
 (11,5,'jai.mp4');
/*!40000 ALTER TABLE `coursevideostl` ENABLE KEYS */;


--
-- Definition of table `emptl`
--

DROP TABLE IF EXISTS `emptl`;
CREATE TABLE `emptl` (
  `empId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `orgId` int(10) unsigned NOT NULL,
  `empName` varchar(60) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `empCode` int(10) unsigned NOT NULL,
  `emailId` varchar(100) NOT NULL,
  `mobaileNo` varchar(13) NOT NULL,
  `password` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`empId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emptl`
--

/*!40000 ALTER TABLE `emptl` DISABLE KEYS */;
INSERT INTO `emptl` (`empId`,`orgId`,`empName`,`address`,`empCode`,`emailId`,`mobaileNo`,`password`) VALUES 
 (1,1,'Ravi','12-31-21 hamamapm kadiri',123,'ravi@gmail.com','0818181818','ss'),
 (2,1,'Ravi','56-9 tapvmoan',124,'user12@gamil.com','08976489654','ss'),
 (3,1,'hai','12-31-21 hamamapm kadiri',515012,'user12@gmail','8181818181','ss'),
 (4,1,'hetric','13-09 adimurthy nagar',12345,'a@gmail.com','09030309387','ss');
/*!40000 ALTER TABLE `emptl` ENABLE KEYS */;


--
-- Definition of table `organizationtl`
--

DROP TABLE IF EXISTS `organizationtl`;
CREATE TABLE `organizationtl` (
  `orgId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `regNo` int(10) unsigned NOT NULL,
  `emailId` varchar(60) NOT NULL,
  `address` varchar(500) NOT NULL,
  `mobaileNo` varchar(13) NOT NULL,
  `contactPersonName` varchar(60) NOT NULL,
  `status` varchar(100) NOT NULL,
  `createdON` datetime NOT NULL,
  `updatedON` datetime NOT NULL,
  `password` varchar(30) NOT NULL,
  PRIMARY KEY (`orgId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `organizationtl`
--

/*!40000 ALTER TABLE `organizationtl` DISABLE KEYS */;
INSERT INTO `organizationtl` (`orgId`,`name`,`regNo`,`emailId`,`address`,`mobaileNo`,`contactPersonName`,`status`,`createdON`,`updatedON`,`password`) VALUES 
 (1,'K VINOD',3442,'swethumadhav@gmail.com','Dharmavaram, Dharmavaram','86888735','as','pending','2018-03-29 00:00:00','2018-03-29 00:00:00','12345'),
 (2,'K  swethu',24325,'swethumadhav@gmail.com','Dharmavaram, Dharmavaram','8688873539','ravi','pending','2018-03-29 00:00:00','2018-03-29 00:00:00','acasvpst');
/*!40000 ALTER TABLE `organizationtl` ENABLE KEYS */;


--
-- Definition of table `requestemptl`
--

DROP TABLE IF EXISTS `requestemptl`;
CREATE TABLE `requestemptl` (
  `reqeId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `empId` int(10) unsigned NOT NULL,
  `status` varchar(100) NOT NULL,
  `reqid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`reqeId`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `requestemptl`
--

/*!40000 ALTER TABLE `requestemptl` DISABLE KEYS */;
INSERT INTO `requestemptl` (`reqeId`,`empId`,`status`,`reqid`) VALUES 
 (1,1,'Active',1),
 (2,2,'Active',1),
 (3,3,'Active',1),
 (4,1,'Active',1),
 (5,3,'Active',1),
 (6,4,'Active',1),
 (7,1,'Active',2),
 (8,3,'Active',2),
 (9,4,'Active',2);
/*!40000 ALTER TABLE `requestemptl` ENABLE KEYS */;


--
-- Definition of table `requesttl`
--

DROP TABLE IF EXISTS `requesttl`;
CREATE TABLE `requesttl` (
  `requestId` int(10) unsigned NOT NULL,
  `orgId` int(10) unsigned NOT NULL,
  `courseId` int(10) unsigned NOT NULL,
  `status` varchar(100) NOT NULL,
  `createdON` datetime NOT NULL,
  PRIMARY KEY (`requestId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `requesttl`
--

/*!40000 ALTER TABLE `requesttl` DISABLE KEYS */;
INSERT INTO `requesttl` (`requestId`,`orgId`,`courseId`,`status`,`createdON`) VALUES 
 (1,1,5,'Paid','2018-04-03 00:00:00'),
 (2,1,5,'Paid','2018-04-03 00:00:00');
/*!40000 ALTER TABLE `requesttl` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
