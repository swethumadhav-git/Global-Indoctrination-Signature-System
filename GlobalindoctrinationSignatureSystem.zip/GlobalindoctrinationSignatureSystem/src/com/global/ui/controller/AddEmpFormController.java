package com.global.ui.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.global.service.EmpService;
import com.global.service.dto.EmpDTO;
import com.global.service.dto.OrganizationDTO;
import com.global.ui.forms.EmpForm;

public class AddEmpFormController extends AbstractFormController {
	
	private EmpService empService;
	
	public AddEmpFormController(EmpService empService){
		this.empService=empService;
	}

	@Override
	public void execute(HttpServletRequest request,
			HttpServletResponse response, Object command)
			throws ServletException, IOException {
		EmpForm empForm=(EmpForm)command;
		EmpDTO empDTO=new EmpDTO();
		HttpSession session=request.getSession();
		 
		OrganizationDTO org=(OrganizationDTO)session.getAttribute("Organization");
		empDTO.setOrgId(org.getOrgId());
		empDTO.setEmpName(empForm.getEmpName());
		empDTO.setAddress(empForm.getAddress());
		empDTO.setEmpCode(empForm.getEmpCode());
		empDTO.setEmailId(empForm.getEmailId());
		empDTO.setMobaileNo(empForm.getMobaileNo());
		
		empService.saveEmp(empDTO);
		response.sendRedirect("showaddemp.htm");
		
		
	}

}
