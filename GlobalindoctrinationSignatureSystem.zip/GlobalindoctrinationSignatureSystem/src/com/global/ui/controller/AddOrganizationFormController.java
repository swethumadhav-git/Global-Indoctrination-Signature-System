package com.global.ui.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.global.service.OrganizationService;
import com.global.service.dto.OrganizationDTO;
import com.global.ui.forms.OrganizationForm;

public class AddOrganizationFormController extends AbstractFormController {

	private OrganizationService organizationService;

	public AddOrganizationFormController(OrganizationService organizationService) {
		this.organizationService = organizationService;
	}

	@Override
	public void execute(HttpServletRequest request,
			HttpServletResponse response, Object command)
			throws ServletException, IOException {
		OrganizationForm organizationForm = (OrganizationForm) command;
		OrganizationDTO organizationDTO = new OrganizationDTO();
		organizationDTO.setName(organizationForm.getName());
		organizationDTO.setRegNo(organizationForm.getRegNo());
		organizationDTO.setEmailId(organizationForm.getEmailId());
		organizationDTO.setAddress(organizationForm.getAddress());
		organizationDTO.setMobaileNo(organizationForm.getMobaileNo());
		organizationDTO.setContactPersonName(organizationForm
				.getContactPersonName());
		organizationDTO.setCreatedON(organizationForm.getCreatedON());
		organizationDTO.setUpdatedON(organizationForm.getUpdatedON());
		organizationDTO.setPassword(organizationForm.getPassword());
		organizationDTO.setStatus("pending");
		organizationService.saveOrganization(organizationDTO);
		response.sendRedirect("addorganization.htm");

	}

}
