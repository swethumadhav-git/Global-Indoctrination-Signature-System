package com.global.ui.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.global.service.CourseService;
import com.global.service.EmpService;
import com.global.service.dto.CourseDTO;
import com.global.service.dto.EmpDTO;
import com.global.service.dto.OrganizationDTO;

public class ShowAddRequestEmpController implements Controller {
	private CourseService courseService;
	private EmpService empService;
	

	public ShowAddRequestEmpController(CourseService courseService, EmpService empService) {
		super();
		this.courseService = courseService;
		this.empService = empService;
	}


	@Override
	public void handleRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<CourseDTO> course = courseService.loadCourses();
		request.setAttribute("course", course);
		HttpSession session = request.getSession(false);

		OrganizationDTO emp = (OrganizationDTO) session.getAttribute("Organization");
		List<EmpDTO> emps = empService.loadEmps(emp.getOrgId());
		request.setAttribute("emps", emps);

		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/pages/AddRequestEmp.jsp");

		rd.forward(request, response);

	}

}
