package com.global.ui.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.global.service.dto.AdminDTO;
import com.global.service.dto.EmpDTO;
import com.global.service.dto.OrganizationDTO;

public class EmpHomeController implements Controller {

	@Override
	public void handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession(false);
		if (session!=null) {
			EmpDTO authorg=(EmpDTO)session.getAttribute("emp");
			if (authorg!=null) {
				RequestDispatcher rd=request.getRequestDispatcher("/WEB-INF/pages/EmpHome.jsp");
				rd.forward(request, response);
				
			}else {
				response.sendRedirect("OrganizationLogin.jsp");
			}
			
		}else {
			response.sendRedirect("OrganizationLogin.jsp");
		}
	}

}
