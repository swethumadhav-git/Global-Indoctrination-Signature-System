package com.global.ui.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.global.service.OrganizationService;
import com.global.service.dto.OrganizationDTO;

public class OrganizationController implements Controller {
	private OrganizationService organizationService;
	
	public OrganizationController(OrganizationService organizationService){
		this.organizationService=organizationService;
	}

	@Override
	public void handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		List<OrganizationDTO> organization=organizationService.loadOrganization();
		request.setAttribute("organization", organization);
		RequestDispatcher rd=request.getRequestDispatcher("WEB-INF/pages/Organization.jsp");
		
		
	}

}
