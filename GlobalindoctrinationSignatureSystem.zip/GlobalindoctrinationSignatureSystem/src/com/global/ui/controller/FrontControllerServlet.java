package com.global.ui.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.global.service.AdminService;
import com.global.service.CourseService;
import com.global.service.CourseVideosService;
import com.global.service.EmpService;
import com.global.service.OrganizationService;
import com.global.service.RequestEmpService;
import com.global.service.RequestService;
import com.global.service.impl.AdminServiceImpl;
import com.global.service.impl.CourseServiceImpl;
import com.global.service.impl.CourseVideosServiceImpl;
import com.global.service.impl.EmpServiceImpl;
import com.global.service.impl.OrganizationServiceImpl;
import com.global.service.impl.RequestEmpServiceImpl;
import com.global.service.impl.RequestServiceImpl;
import com.global.ui.forms.AdminForm;
import com.global.ui.forms.CourseForm;
import com.global.ui.forms.CourseVideosForm;
import com.global.ui.forms.EmpForm;
import com.global.ui.forms.OrganizationForm;
import com.global.ui.forms.RequestEmpForm;
import com.global.ui.forms.RequestForm;

public class FrontControllerServlet extends HttpServlet {
	private CourseService courseService;
	private CourseVideosService courseVideosService;
	private EmpService empService;
	private OrganizationService organizationService;
	private RequestEmpService requestEmpService;
	private RequestService requestService;
	private AdminService adminService;

	@Override
	public void init() throws ServletException {
		adminService = new AdminServiceImpl();
		organizationService = new OrganizationServiceImpl();
		courseService = new CourseServiceImpl();
		courseVideosService = new CourseVideosServiceImpl();
		empService = new EmpServiceImpl();
		requestEmpService = new RequestEmpServiceImpl();
		requestService = new RequestServiceImpl();

	}

	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String path = request.getServletPath();

		if (path.equalsIgnoreCase("/showaddcourse.htm")) {
			ShowAddCourseController sacc = new ShowAddCourseController();
			sacc.handleRequest(request, response);
		}
		else if (path.equalsIgnoreCase("/success.htm")) {
			SuccessController sacc = new SuccessController(requestService,requestEmpService);
			sacc.handleRequest(request, response);
		}

		else if (path.equalsIgnoreCase("/showadminlogin.htm")) {
			ShowAdminController sac = new ShowAdminController();
			sac.handleRequest(request, response);

		}
		else if (path.equalsIgnoreCase("/emphome.htm")) {
			EmpHomeController empHomeController=new EmpHomeController();
			empHomeController.handleRequest(request, response);
			
		}
		
		else if (path.equalsIgnoreCase("/empcourses.htm")) {
			EmpCoursesController empCoursesController=new EmpCoursesController(courseService);
			empCoursesController.handleRequest(request, response);
			
		}
		
		else if (path.equalsIgnoreCase("/go.htm")) 
		{
			GoCourseVdController courseVdController=new GoCourseVdController(courseService, courseVideosService);
			courseVdController.handleRequest(request, response);
		}

		else if (path.equalsIgnoreCase("/showorganizationlogin.htm")) {
			ShowOrganizationLoginController solc = new ShowOrganizationLoginController();
			solc.handleRequest(request, response);

		}

		else if (path.equalsIgnoreCase("/adminhome.htm")) {
			AdminHomeController ahc = new AdminHomeController();
			ahc.handleRequest(request, response);

		}

		else if (path.equals("/organizationhome.htm")) {
			OrganizationHomeController ohc = new OrganizationHomeController();
			ohc.handleRequest(request, response);

		}

		else if (path.equalsIgnoreCase("/showaddcoursevideos.htm")) {
			ShowAddCourseVideosController sacvc = new ShowAddCourseVideosController(courseService);
			sacvc.handleRequest(request, response);
		}

		else if (path.equalsIgnoreCase("/adminlogout.htm")) {
			AdminLogoutContrller alc = new AdminLogoutContrller();
			alc.handleRequest(request, response);

		}

		else if (path.equalsIgnoreCase("/organizationlogout.htm")) {
			OrganizationLogoutFormController olfc = new OrganizationLogoutFormController();
			olfc.handleRequest(request, response);

		}

		else if (path.equalsIgnoreCase("/showaddemp.htm")) {
			ShowAddEmpController saec = new ShowAddEmpController();
			saec.handleRequest(request, response);
		}
		else if (path.equalsIgnoreCase("/myemp.htm")) {
			MYorgemp mo = new MYorgemp(empService);
			mo.handleRequest(request, response);
		}
		else if (path.equalsIgnoreCase("/showaddorganization.htm")) {
			ShowAddOrganizationController saoc = new ShowAddOrganizationController();
			saoc.handleRequest(request, response);
		}
		
		

		else if (path.equalsIgnoreCase("/showaddrequestemp.htm")) {
			ShowAddRequestEmpController sarec = new ShowAddRequestEmpController(courseService, empService);
			sarec.handleRequest(request, response);
		}

		else if (path.equalsIgnoreCase("/showaddrequest.htm")) {
			ShowAddRequestController sarc = new ShowAddRequestController();
			sarc.handleRequest(request, response);
		}

		else if (path.equalsIgnoreCase("/course.htm")) {
			CourseController cc = new CourseController(courseService);
			cc.handleRequest(request, response);
		}

		else if (path.equalsIgnoreCase("/admincourse.htm")) {
			AdminCourseController cc = new AdminCourseController(courseService);
			cc.handleRequest(request, response);
		}
		else if (path.equalsIgnoreCase("/coursevideos.htm")) {
			CourseVideosController cvc = new CourseVideosController(
					courseVideosService);
			cvc.handleRequest(request, response);

		}

		else if (path.equalsIgnoreCase("/emp.htm")) {
			EmpController ec = new EmpController(empService);
			ec.handleRequest(request, response);

		}

		else if (path.equalsIgnoreCase("/oganization.htm")) {
			OrganizationController oc = new OrganizationController(
					organizationService);
			oc.handleRequest(request, response);

		}

		else if (path.equalsIgnoreCase("/requestemp.htm")) {
			RequestEmpController rec = new RequestEmpController(
					requestEmpService);
			rec.handleRequest(request, response);

		}
		else if (path.equalsIgnoreCase("/showpayment.htm")) {
			PaymentController paymentController=new PaymentController();
			paymentController.handleRequest(request, response);
			
		}
		
	
		
		

		else if (path.equalsIgnoreCase("/request.htm")) {
			RequestController rc = new RequestController(requestService);
			rc.handleRequest(request, response);
		}/*
		 * else if(path.equalsIgnoreCase("/mycourses.htm")){ MyCourseContrller
		 * mcc=new MyCourseContrller(courseService); mcc.handleRequest(request,
		 * response);
		 * 
		 * }
		 */

	}

	@Override
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String path = request.getServletPath();
		if (path.equalsIgnoreCase("/adminlogin.htm")) {
			String emailId = request.getParameter("emailId");
			String password = request.getParameter("password");

			AdminForm adminForm = new AdminForm();
			adminForm.setEmailId(emailId);
			adminForm.setPassword(password);

			AdminLoginFormController alfc = new AdminLoginFormController(
					adminService);
			alfc.execute(request, response, adminForm);

		}
		else if (path.equalsIgnoreCase("/payuform.htm")) {
			PayuFormController payuFormController=new PayuFormController();
			payuFormController.handleRequest(request, response);
			
		}
		
		
		else if (path.equalsIgnoreCase("/org.htm")) {
			String emailId = request.getParameter("emailId");
			String password = request.getParameter("password");
			OrganizationForm orgform=new OrganizationForm();
			orgform.setEmailId(emailId);
			orgform.setPassword(password);
			
			
			OrganizationLoginFormController orlf = new OrganizationLoginFormController(organizationService,empService);
			orlf.execute(request, response, orgform);
		}

		else if (path.equalsIgnoreCase("/addcourse.htm")) {
			CourseForm courseForm = new CourseForm();
			courseForm.setCourseName(request.getParameter("courseName"));
			courseForm.setCourseDescription(request
					.getParameter("courseDescription"));
			courseForm
					.setCourseSyllabus(request.getParameter("courseSyllabus"));
			courseForm
					.setCourseDuration(request.getParameter("courseDuration"));
			courseForm.setAmount(Float.valueOf(request.getParameter("amount")));
			courseForm.setDiscount(Float.valueOf(request
					.getParameter("discount")));
			courseForm.setCateType(request.getParameter("cateType"));

			AddCourseFormController acfc = new AddCourseFormController(
					courseService);
			acfc.execute(request, response, courseForm);

		}

		else if (path.equalsIgnoreCase("/addcoursevideos.htm")) {
			CourseVideosForm courseVideosForm = new CourseVideosForm();
			courseVideosForm.setCourseId(Integer.valueOf(request
					.getParameter("courseId")));
			courseVideosForm.setVideoName(request.getParameter("videoName"));

			AddCourseVideosFormController acvfc = new AddCourseVideosFormController(
					courseVideosService);
			acvfc.execute(request, response, courseVideosForm);
		}

		else if (path.equalsIgnoreCase("/addemp.htm")) {
			EmpForm empForm = new EmpForm();
			
			//empForm.setOrgId(Integer.valueOf(request.getParameter("orgId")));
			empForm.setEmpName(request.getParameter("empName"));
			empForm.setAddress(request.getParameter("address"));
			empForm.setEmpCode(Integer.valueOf(request.getParameter("empCode")));
			empForm.setEmailId(request.getParameter("emailId"));
			empForm.setMobaileNo(request.getParameter("mobaileNo"));

			AddEmpFormController aefc = new AddEmpFormController(empService);
			aefc.execute(request, response, empForm);
		}

		else if (path.equalsIgnoreCase("/addorganization.htm")) {
			OrganizationForm organizationForm = new OrganizationForm();
			organizationForm.setName(request.getParameter("name"));
			organizationForm
					.setRegNo(new Integer(request.getParameter("regNo")));
			organizationForm.setEmailId(request.getParameter("emailId"));
			organizationForm.setAddress(request.getParameter("address"));
			organizationForm.setMobaileNo(request.getParameter("mobaileNo"));
			organizationForm.setContactPersonName(request
					.getParameter("contactPersonName"));

			organizationForm.setUpdatedON(new java.util.Date());
			organizationForm.setCreatedON(new java.util.Date());
			organizationForm.setStatus("status");
			organizationForm.setPassword(request.getParameter("password"));

			AddOrganizationFormController aofc = new AddOrganizationFormController(
					organizationService);
			aofc.execute(request, response, organizationForm);
		}

		else if (path.equalsIgnoreCase("/addrequestemp.htm")) {
			

			AddRequestEmpFormController arefc = new AddRequestEmpFormController(
					courseService);
			arefc.execute(request, response, null);
		}

		else if (path.equalsIgnoreCase("/addrequest.htm")) {
			RequestForm requestForm = new RequestForm();
			requestForm
					.setOrgId(Integer.valueOf(request.getParameter("orgId")));
			requestForm.setCourseId(Integer.valueOf(request
					.getParameter("courseId")));
			requestForm.setCreatedON(new java.util.Date());

			AddRequestFormController arfc = new AddRequestFormController(
					requestService);
			arfc.execute(request, response, requestForm);
		}

	}

	@Override
	public void destroy() {
		adminService = null;
		organizationService = null;
		courseService = null;
		requestEmpService = null;
		courseVideosService = null;
		requestService = null;
		empService = null;

	}

}
