package com.global.ui.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.global.service.AdminService;
import com.global.service.EmpService;
import com.global.service.OrganizationService;
import com.global.service.dto.AdminDTO;
import com.global.service.dto.EmpDTO;
import com.global.service.dto.OrganizationDTO;
import com.global.ui.forms.AdminForm;
import com.global.ui.forms.OrganizationForm;

public class OrganizationLoginFormController extends AbstractFormController {
	private OrganizationService organizationService;
	private EmpService empService;
	public OrganizationLoginFormController(OrganizationService organizationService,EmpService empService) {
	this.organizationService=organizationService;
	this.empService=empService;
	}

	@Override
	public void execute(HttpServletRequest request,
			HttpServletResponse response, Object command)
			throws ServletException, IOException {
		OrganizationForm organizationForm=(OrganizationForm)command;
		OrganizationDTO org=organizationService.getOrganization(organizationForm.getEmailId(),organizationForm.getPassword());
		if (org!=null) {
			HttpSession session=request.getSession();
			session.setAttribute("Organization", org);
			response.sendRedirect("organizationhome.htm");
			
		}else {
			EmpDTO empDTO=empService.loadEmp(organizationForm.getEmailId(),organizationForm.getPassword());
			
			if(empDTO!=null)
			{
				HttpSession session=request.getSession();
				session.setAttribute("emp", empDTO);
				response.sendRedirect("emphome.htm");
			}
			else
			{
				request.setAttribute("Message", "Invalid Request Try Again");
				RequestDispatcher rd=request.getRequestDispatcher("OrganizationLogin.jsp");
				rd.forward(request, response);
			}
		}
		
	}



}
