package com.global.ui.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.global.service.RequestService;
import com.global.service.dto.RequestDTO;
import com.global.ui.forms.RequestForm;

public class AddRequestFormController extends AbstractFormController {
	
	private RequestService requestService;
	
	public AddRequestFormController(RequestService requestService){
		this.requestService=requestService;
	}

	@Override
	public void execute(HttpServletRequest request,
			HttpServletResponse response, Object command)
			throws ServletException, IOException {
		RequestForm requestForm=(RequestForm)command;
		RequestDTO requestDTO=new RequestDTO();
		requestDTO.setOrgId(requestForm.getOrgId());
		requestDTO.setCourseId(requestForm.getCourseId());
		requestDTO.setCreatedON(requestForm.getCreatedON());
		
		requestService.saveRequest(requestDTO);
		response.sendRedirect("addrequest.htm");
		
	}

}
