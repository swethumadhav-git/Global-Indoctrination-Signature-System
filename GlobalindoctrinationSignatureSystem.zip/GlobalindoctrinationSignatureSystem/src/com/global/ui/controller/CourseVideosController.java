package com.global.ui.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.global.service.CourseVideosService;
import com.global.service.dto.CourseVideosDTO;

public class CourseVideosController implements Controller {
	private CourseVideosService courseVideosService;
	
	public CourseVideosController(CourseVideosService courseVideosService){
		this.courseVideosService=courseVideosService;
	}
	@Override
	public void handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		List<CourseVideosDTO> courseVideos=courseVideosService.loadCourseVideos();
		request.setAttribute("courseVideos", courseVideos);
		RequestDispatcher rd=request.getRequestDispatcher("WEB-INF/pages/CourseVideos.jsp");
		
		
	}

}
