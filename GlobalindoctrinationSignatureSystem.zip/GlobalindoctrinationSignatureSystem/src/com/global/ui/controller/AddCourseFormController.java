package com.global.ui.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.global.service.CourseService;
import com.global.service.dto.CourseDTO;
import com.global.ui.forms.CourseForm;

public class AddCourseFormController extends AbstractFormController {

	private CourseService courseService;

	public AddCourseFormController(CourseService courseService) {
		this.courseService = courseService;
	}

	public void execute(HttpServletRequest request,
			HttpServletResponse response, Object command)
			throws ServletException, IOException {
		CourseForm courseForm = (CourseForm) command;
		CourseDTO courseDTO = new CourseDTO();
		courseDTO.setCourseName(courseForm.getCourseName());
		courseDTO.setCourseDescription(courseForm.getCourseDescription());
		courseDTO.setCourseSyllabus(courseForm.getCourseSyllabus());
		courseDTO.setCourseDuration(courseForm.getCourseDuration());
		courseDTO.setAmount(courseForm.getAmount());
		courseDTO.setDiscount(courseForm.getDiscount());
		courseDTO.setCateType(courseForm.getCateType());

		courseService.saveCourse(courseDTO);
		response.sendRedirect("adminhome.htm");

	}

}
