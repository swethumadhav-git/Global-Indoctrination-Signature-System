package com.global.ui.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.global.dao.RequestDAO;
import com.global.service.RequestEmpService;
import com.global.service.RequestService;
import com.global.service.dto.OrganizationDTO;
import com.global.service.dto.RequestDTO;
import com.global.service.dto.RequestEmpDTO;



public class SuccessController implements Controller {
	private RequestService requestService;
	private RequestEmpService requestEmpService;
	




	public SuccessController(RequestService requestService, RequestEmpService requestEmpService) {
		super();
		this.requestService = requestService;
		this.requestEmpService=requestEmpService;
	}





	@Override
	public void handleRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		Integer courseId=(Integer)session.getAttribute("courseId");
		Float amt=(Float)session.getAttribute("amt");
		Integer[] eids=(Integer[])session.getAttribute("eids");
		RequestDTO requestDTO=new RequestDTO();
		requestDTO.setCourseId(courseId);
		OrganizationDTO orgg = (OrganizationDTO) session.getAttribute("Organization");
		requestDTO.setOrgId(orgg.getOrgId());
		requestDTO.setCreatedON(new java.util.Date());
		Integer orderId=requestService.saveRequest(requestDTO);
		for(Integer eid:eids)
		{
		RequestEmpDTO edt=new RequestEmpDTO();
		edt.setEmpId(eid);
		edt.setReqId(orderId);
		edt.setStatus("Active");
		requestEmpService.saveRequestEmp(edt);
		
		
		}
		request.setAttribute("amt",amt);

		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/pages/success.jsp");
		rd.forward(request, response);
		
	}

}
