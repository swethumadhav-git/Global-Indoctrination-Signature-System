package com.global.ui.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.global.service.AdminService;
import com.global.service.dto.AdminDTO;
import com.global.ui.forms.AdminForm;

public class AdminLoginFormController extends AbstractFormController {
	private AdminService adminService;
	public AdminLoginFormController(AdminService adminService) {
	this.adminService=adminService;
	}

	@Override
	public void execute(HttpServletRequest request,
			HttpServletResponse response, Object command)
			throws ServletException, IOException {
		AdminForm adminForm=(AdminForm)command;
		AdminDTO admin=adminService.getAdmin(adminForm.getEmailId(), adminForm.getPassword());
		if (admin!=null) {
			HttpSession session=request.getSession();
			session.setAttribute("Admin", admin);
			response.sendRedirect("adminhome.htm");
			
		}else {
			request.setAttribute("Message", "Invalid Request Try Again");
			RequestDispatcher rd=request.getRequestDispatcher("AdminLogin.jsp");
			rd.forward(request, response);
		}
		
	}
	

}
