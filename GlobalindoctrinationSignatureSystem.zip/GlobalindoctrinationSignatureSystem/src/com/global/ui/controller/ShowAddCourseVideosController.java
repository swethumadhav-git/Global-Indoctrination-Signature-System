package com.global.ui.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.global.service.CourseService;
import com.global.service.dto.CourseDTO;

public class ShowAddCourseVideosController implements Controller{
	private CourseService courseService;
	public ShowAddCourseVideosController(CourseService courseService) {
		super();
		this.courseService = courseService;
	}

	@Override
	public void handleRequest(HttpServletRequest request,
			HttpServletResponse response)
			throws ServletException, IOException {
		List<CourseDTO> course=courseService.loadCourses();
		request.setAttribute("course", course);
		RequestDispatcher rd = request
				.getRequestDispatcher("/WEB-INF/pages/AddCourseVideos.jsp");

		rd.forward(request, response);
		
	}

}
