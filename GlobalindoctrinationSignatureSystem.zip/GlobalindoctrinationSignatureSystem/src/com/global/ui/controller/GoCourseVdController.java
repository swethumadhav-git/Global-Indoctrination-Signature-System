package com.global.ui.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.global.service.CourseService;
import com.global.service.CourseVideosService;
import com.global.service.dto.CourseDTO;
import com.global.service.dto.CourseVideosDTO;

public class GoCourseVdController implements Controller {
	private CourseService courseService;
	private CourseVideosService courseVideosService;

	public GoCourseVdController(CourseService courseService,  CourseVideosService courseVideosService) {
		super();
		this.courseService = courseService;
		this.courseVideosService = courseVideosService;
	}

	@Override
	public void handleRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String cid = request.getParameter("cid");
		CourseDTO courseDTO = courseService.loadCourse(new Integer(cid));
		request.setAttribute("course", courseDTO);
		List<CourseVideosDTO> courseVideos=courseVideosService.loadCourseVideos(new Integer(cid));
		request.setAttribute("courseVideos", courseVideos);
		RequestDispatcher rd=request.getRequestDispatcher("/WEB-INF/pages/EmpCourseVideos.jsp");
		rd.forward(request, response);

	}

}
