package com.global.ui.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.global.service.CourseService;
import com.global.service.RequestEmpService;
import com.global.service.dto.CourseDTO;
import com.global.service.dto.RequestEmpDTO;
import com.global.ui.forms.RequestEmpForm;

public class AddRequestEmpFormController extends AbstractFormController {

	private CourseService courseService;

	public AddRequestEmpFormController(CourseService courseService) {

		this.courseService = courseService;
	}

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response, Object command)
			throws ServletException, IOException {
		/*
		 * RequestEmpForm requestEmpForm=(RequestEmpForm)command; RequestEmpDTO
		 * requestEmpDTO=new RequestEmpDTO();
		 * requestEmpDTO.setEmpId(requestEmpForm.getEmpId());
		 * 
		 * requestEmpService.saveRequestEmp(requestEmpDTO);
		 */

		String[] eids = request.getParameterValues("empId");
		if (eids != null && eids.length > 0) {
			Integer courseId = new Integer(request.getParameter("courseId"));
			CourseDTO courseDTO = courseService.loadCourse(courseId);
			Integer[] empid = new Integer[eids.length];
			for (int index = 0; index < empid.length; index++) {
				empid[index] = Integer.valueOf(eids[index]);

			}
			Float amount = courseDTO.getAmount() - courseDTO.getDiscount();
			amount = amount * empid.length;

			HttpSession session = request.getSession();
			session.setAttribute("courseId", courseId);
			session.setAttribute("eids", empid);
			session.setAttribute("amt", amount);
			response.sendRedirect("showpayment.htm");

		} else {

			response.sendRedirect("addrequestemp.htm");
		}

	}

}
