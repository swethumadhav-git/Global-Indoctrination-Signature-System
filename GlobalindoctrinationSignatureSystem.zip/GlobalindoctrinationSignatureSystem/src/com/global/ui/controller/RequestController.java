package com.global.ui.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.global.service.RequestService;
import com.global.service.dto.RequestDTO;

public class RequestController implements Controller {
	private RequestService requestService;
	
	public RequestController(RequestService requestService){
		this.requestService=requestService;
	}

	@Override
	public void handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		List<RequestDTO> requests=requestService.loadRequest();
		request.setAttribute("requests", requests);
		RequestDispatcher rd=request.getRequestDispatcher("WEB-INF/pages/Request.jsp");
		
		
	}

}
