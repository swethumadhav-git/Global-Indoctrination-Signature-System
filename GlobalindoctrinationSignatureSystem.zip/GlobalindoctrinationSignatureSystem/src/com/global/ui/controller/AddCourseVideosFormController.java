package com.global.ui.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.global.service.CourseVideosService;
import com.global.service.dto.CourseVideosDTO;
import com.global.ui.forms.CourseVideosForm;

public class AddCourseVideosFormController extends AbstractFormController {

	CourseVideosService courseVideosService;

	public AddCourseVideosFormController(CourseVideosService courseVideosService) {
		this.courseVideosService = courseVideosService;
	}

	@Override
	public void execute(HttpServletRequest request,
			HttpServletResponse response, Object command)
			throws ServletException, IOException {
		CourseVideosForm courseVideosForm = (CourseVideosForm) command;
		CourseVideosDTO courseVideosDTO = new CourseVideosDTO();
		courseVideosDTO.setCourseId(courseVideosForm.getCourseId());
		courseVideosDTO.setVideoName(courseVideosForm.getVideoName());

		courseVideosService.saveCourseVideo(courseVideosDTO);
		response.sendRedirect("adminhome.htm");

	}

}
