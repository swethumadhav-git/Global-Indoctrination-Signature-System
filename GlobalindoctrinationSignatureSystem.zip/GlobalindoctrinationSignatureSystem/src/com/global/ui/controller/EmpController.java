package com.global.ui.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.global.service.EmpService;
import com.global.service.dto.EmpDTO;



public class EmpController implements Controller {
	private EmpService empService;
	public EmpController(EmpService empService){
		this.empService=empService;
	}

	@Override
	public void handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		List<EmpDTO> emp=empService.loadEmp();
		request.setAttribute("emp", emp);
		RequestDispatcher rd=request.getRequestDispatcher("WEB-INF/pages/Emp.jsp");
		
	}

	

}
