package com.global.ui.forms;

import java.util.Date;

public class OrganizationForm {
	private String name;
	private Integer regNo;
	private String emailId;
	private String address;
	private String mobaileNo;
	private String contactPersonName;
	private Date createdON;
	private Date updatedON;
	private String Status;
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	private String password;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getRegNo() {
		return regNo;
	}
	public void setRegNo(Integer regNo) {
		this.regNo = regNo;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMobaileNo() {
		return mobaileNo;
	}
	public void setMobaileNo(String mobaileNo) {
		this.mobaileNo = mobaileNo;
	}
	public String getContactPersonName() {
		return contactPersonName;
	}
	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}
	public Date getCreatedON() {
		return createdON;
	}
	public void setCreatedON(Date createdON) {
		this.createdON = createdON;
	}
	public Date getUpdatedON() {
		return updatedON;
	}
	public void setUpdatedON(Date updatedON) {
		this.updatedON = updatedON;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	

}
