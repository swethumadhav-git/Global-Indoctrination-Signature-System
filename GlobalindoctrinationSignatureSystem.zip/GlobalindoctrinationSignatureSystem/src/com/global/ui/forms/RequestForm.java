package com.global.ui.forms;

import java.util.Date;

public class RequestForm {
	private Integer orgId;
	private Integer courseId;
	private Date createdON;
	public Integer getOrgId() {
		return orgId;
	}
	public void setOrgId(Integer orgId) {
		this.orgId = orgId;
	}
	public Integer getCourseId() {
		return courseId;
	}
	public void setCourseId(Integer courseId) {
		this.courseId = courseId;
	}
	public Date getCreatedON() {
		return createdON;
	}
	public void setCreatedON(Date createdON) {
		this.createdON = createdON;
	}
	

}
