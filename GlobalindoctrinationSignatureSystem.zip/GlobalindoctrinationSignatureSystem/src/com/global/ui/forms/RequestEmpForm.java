package com.global.ui.forms;

public class RequestEmpForm {
	private Integer empId;

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	

}
