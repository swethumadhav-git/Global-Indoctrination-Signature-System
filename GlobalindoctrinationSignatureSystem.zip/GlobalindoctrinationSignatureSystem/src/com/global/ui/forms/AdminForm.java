package com.global.ui.forms;

public class AdminForm {
	private Integer adminId;
	private String name;
	private String emailId;
	private String mobaileNo;
	private String password;
	private String status;
	public Integer getAdminId() {
		return adminId;
	}
	public void setAdminId(Integer adminId) {
		this.adminId = adminId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getMobaileNo() {
		return mobaileNo;
	}
	public void setMobaileNo(String mobaileNo) {
		this.mobaileNo = mobaileNo;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

}
