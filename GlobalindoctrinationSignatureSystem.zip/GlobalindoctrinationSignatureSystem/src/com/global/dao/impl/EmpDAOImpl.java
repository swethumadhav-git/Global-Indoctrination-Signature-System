package com.global.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.global.dao.EmpDAO;
import com.global.dao.model.EmpTL;
import com.global.dao.util.JDBCUtility;

public class EmpDAOImpl implements EmpDAO {

	@Override
	public void insertEmp(EmpTL emp) {
		PreparedStatement pst = null;
		try {
			pst = JDBCUtility
					.getConnection()
					.prepareStatement(
							"insert into EmpTL(orgId,empName,address,empCode,emailId,mobaileNo,password) values (?,?,?,?,?,?,?)");
			pst.setInt(1, emp.getOrgId());
			pst.setString(2, emp.getEmpName());
			pst.setString(3, emp.getAddress());
			pst.setInt(4, emp.getEmpCode());
			pst.setString(5, emp.getEmailId());
			pst.setString(6, emp.getMobaileNo());
			pst.setString(7, emp.getEmpName().substring(0, 1)+emp.getEmpCode());
//			pst.setString(7, emp.getStatus());
			pst.executeUpdate();

		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeStatement(pst);
		}

	}

	@Override
	public EmpTL getEmp(Integer empId) {
		EmpTL empTL = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			String sql = "selecr empId,orgId,empName,address,empCode,emailId,mobaileNo,status from EmpTL where empId=?";
			pst = JDBCUtility.getConnection().prepareStatement(sql);
			pst.setInt(1, empId);
			rs = pst.executeQuery();
			if (rs.next()) {
				empTL = new EmpTL();
				empTL.setEmpId(rs.getInt("empId"));
				empTL.setOrgId(rs.getInt("orgId"));
				empTL.setEmpName(rs.getString("empName"));
				empTL.setAddress(rs.getString("address"));
				empTL.setEmpCode(rs.getInt("empCode"));
				empTL.setEmailId(rs.getString("emailId"));
				empTL.setMobaileNo(rs.getString("mobaileNo"));
//				empTL.setStatus(rs.getString("status"));

			}

		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeResultSet(rs);
			JDBCUtility.closeStatement(pst);
		}

		return empTL;
	}

	public EmpTL getEmp(String emailId,String password) {
		EmpTL empTL = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			String sql = "select empId, orgId, empName, address, empCode, emailId, mobaileNo, password from EmpTL where emailId=? and password=? ";
			pst = JDBCUtility.getConnection().prepareStatement(sql);
			pst.setString(1, emailId);
			pst.setString(2, password);
			rs = pst.executeQuery();
			if (rs.next()) {
				empTL = new EmpTL();
				empTL.setEmpId(rs.getInt("empId"));
				empTL.setOrgId(rs.getInt("orgId"));
				empTL.setEmpName(rs.getString("empName"));
				empTL.setAddress(rs.getString("address"));
				empTL.setEmpCode(rs.getInt("empCode"));
				empTL.setEmailId(rs.getString("emailId"));
				empTL.setMobaileNo(rs.getString("mobaileNo"));
			
//				empTL.setStatus(rs.getString("status"));

			}

		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeResultSet(rs);
			JDBCUtility.closeStatement(pst);
		}

		return empTL;
	}
	@Override
	public List<EmpTL> getEmp() {
		List<EmpTL> emp=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="select empId,orgId,empName,address,empCode,emailId,mobaileNo";
			pst=JDBCUtility.getConnection().prepareStatement(sql);
			rs=pst.executeQuery();
			emp=new ArrayList<EmpTL>();
			while(rs.next()){
				EmpTL empTL=new EmpTL();
				empTL.setEmpId(rs.getInt("empId"));
				empTL.setOrgId(rs.getInt("orgId"));
				empTL.setEmpName(rs.getString("empName"));
				empTL.setAddress(rs.getString("address"));
				empTL.setEmpCode(rs.getInt("empCode"));
				empTL.setMobaileNo(rs.getString("mobaileNo"));
//				empTL.setStatus(rs.getString("status"));
				
				emp.add(empTL);
			}
			
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeResultSet(rs);
			JDBCUtility.closeStatement(pst);
		}
		
		
		return emp;
	}

	@Override
	public List<EmpTL> getEmps(Integer orgId) {
		List<EmpTL> emp=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="select empId,orgId,empName,address,empCode,emailId,mobaileNo from EmpTL where orgId=?";
			pst=JDBCUtility.getConnection().prepareStatement(sql);
			pst.setInt(1, orgId);
			rs=pst.executeQuery();
			emp=new ArrayList<EmpTL>();
			while(rs.next()){
				EmpTL empTL=new EmpTL();
				empTL.setEmpId(rs.getInt("empId"));
				empTL.setOrgId(rs.getInt("orgId"));
				empTL.setEmpName(rs.getString("empName"));
				empTL.setAddress(rs.getString("address"));
				empTL.setEmpCode(rs.getInt("empCode"));
				empTL.setMobaileNo(rs.getString("mobaileNo"));
//				empTL.setStatus(rs.getString("status"));
				
				emp.add(empTL);
			}
			
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeResultSet(rs);
			JDBCUtility.closeStatement(pst);
		}
		return emp;
				
	}

}
