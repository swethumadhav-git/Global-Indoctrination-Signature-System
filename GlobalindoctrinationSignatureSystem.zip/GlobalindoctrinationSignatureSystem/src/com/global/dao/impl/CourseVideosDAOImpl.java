package com.global.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.global.dao.CourseVideosDAO;
import com.global.dao.model.CourseVideosTL;
import com.global.dao.util.JDBCUtility;

public class CourseVideosDAOImpl implements CourseVideosDAO {

	public void insertCourseVideo(CourseVideosTL cvideo) {
		PreparedStatement pst = null;
		try {
			pst = JDBCUtility
					.getConnection()
					.prepareStatement(
							"insert into coursevideostl (courseId,videoName) values(?,?)");
			pst.setInt(1, cvideo.getCourseId());
			pst.setString(2, cvideo.getVideoName());
			pst.executeUpdate();

		} catch (SQLException sqle) {
			sqle.printStackTrace();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeStatement(pst);
		}

	}

	@Override
	public CourseVideosTL getCourseVideo(Integer coursevId) {
		CourseVideosTL courseVideosTL = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			String sql = "select coursevId,courseId,videoName from CourseVideosTL where coursevId=?";
			pst = JDBCUtility.getConnection().prepareStatement(sql);
			pst.setInt(1, coursevId);
			rs = pst.executeQuery();
			if (rs.next()) {
				courseVideosTL = new CourseVideosTL();
				courseVideosTL.setCoursevId(rs.getInt("coursevId"));
				courseVideosTL.setCourseId(rs.getInt("courseId"));
				courseVideosTL.setVideoName(rs.getString("videoName"));

			}

		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeResultSet(rs);
			JDBCUtility.closeStatement(pst);
		}

		return courseVideosTL;
	}

	@Override
	public List<CourseVideosTL> getCourseVideos() {
		List<CourseVideosTL> courseVideos=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="select coursevId,courseId,videoName from CouseVideosTL";
			pst=JDBCUtility.getConnection().prepareStatement(sql);
			rs=pst.executeQuery();
			courseVideos=new ArrayList<CourseVideosTL>();
			while(rs.next()){
				CourseVideosTL courseVideosTL=new CourseVideosTL();
				courseVideosTL.setCoursevId(rs.getInt("coursevId"));
				courseVideosTL.setCourseId(rs.getInt("courseId"));
				courseVideosTL.setVideoName(rs.getString("videoName"));
				
				courseVideos.add(courseVideosTL);
			}
			
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeResultSet(rs);
			JDBCUtility.closeStatement(pst);
		}
		
		
		return courseVideos;
	}
	
	public List<CourseVideosTL> getCourseVideos(Integer courseId) {
		List<CourseVideosTL> courseVideos=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="select coursevId, courseId, videoName from coursevideostl where courseId=?";
			pst=JDBCUtility.getConnection().prepareStatement(sql);
			pst.setInt(1, courseId);
			rs=pst.executeQuery();
			courseVideos=new ArrayList<CourseVideosTL>();
			while(rs.next()){
				CourseVideosTL courseVideosTL=new CourseVideosTL();
				courseVideosTL.setCoursevId(rs.getInt("coursevId"));
				courseVideosTL.setCourseId(rs.getInt("courseId"));
				courseVideosTL.setVideoName(rs.getString("videoName"));
				
				courseVideos.add(courseVideosTL);
			}
			
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeResultSet(rs);
			JDBCUtility.closeStatement(pst);
		}
		
		
		return courseVideos;
	}


}
