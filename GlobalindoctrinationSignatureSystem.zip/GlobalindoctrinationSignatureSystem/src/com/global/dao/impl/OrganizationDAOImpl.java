package com.global.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.global.dao.OrganizationDAO;
import com.global.dao.model.AdminTL;
import com.global.dao.model.OrganizationTL;
import com.global.dao.util.JDBCUtility;

public class OrganizationDAOImpl implements OrganizationDAO {

	@Override
	public void insertOrganization(OrganizationTL organization) {
		PreparedStatement pst = null;
		try {
			pst = JDBCUtility
					.getConnection()
					.prepareStatement(
							"insert into organizationtl (name,regNo,emailId,address,mobaileNo,contactPersonName,status,createdON,updatedON,password) values (?,?,?,?,?,?,?,?,?,?)");
			pst.setString(1, organization.getName());
			pst.setInt(2, organization.getRegNo());
			pst.setString(3, organization.getEmailId());
			pst.setString(4, organization.getAddress());
			pst.setString(5, organization.getMobaileNo());

			pst.setString(6, organization.getContactPersonName());
			System.out.println("sttt"+organization.getStatus());
			pst.setString(7, organization.getStatus());
			pst.setDate(8, organization.getCreatedON());
			pst.setDate(9, organization.getUpdatedON());
			pst.setString(10, organization.getPassword());
			pst.executeUpdate();

		} catch (SQLException sqle) {
			sqle.printStackTrace();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeStatement(pst);
		}

	}

	@Override
	public OrganizationTL getOrganization(Integer orgId) {
		OrganizationTL organizationTL = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			String sql = "select orgId,name,regNo,emailId,address,mobaileNo,contactPersonName,status,createdON,updatedON,password from OrganizationTL where orgI=?";
			pst = JDBCUtility.getConnection().prepareStatement(sql);
			pst.setInt(1, orgId);
			rs = pst.executeQuery();
			if (rs.next()) {
				organizationTL = new OrganizationTL();
				organizationTL.setOrgId(rs.getInt("orgId"));
				organizationTL.setName(rs.getString("name"));
				organizationTL.setRegNo(rs.getInt("regNo"));
				organizationTL.setEmailId(rs.getString("emailId"));
				organizationTL.setAddress(rs.getString("address"));
				organizationTL.setMobaileNo(rs.getString("mobaileNo"));
				organizationTL.setContactPersonName(rs
						.getString("contactPersonName"));
				organizationTL.setStatus(rs.getString("status"));
				organizationTL.setCreatedON(rs.getDate("createdON"));
				organizationTL.setUpdatedON(rs.getDate("updatedON"));
				organizationTL.setPassword(rs.getString("password"));

			}

		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeResultSet(rs);
			JDBCUtility.closeStatement(pst);
		}

		return organizationTL;
	}

	@Override
	public List<OrganizationTL> getOrganization() {
		List<OrganizationTL> organization = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			String sql = "select orgId,name,regNo,emailId,address,mobaileNo,contactPersonName,status,createdON,updatedON,password from OrganizationTL ";
			pst = JDBCUtility.getConnection().prepareStatement(sql);
			rs = pst.executeQuery();
			organization = new ArrayList<OrganizationTL>();
			while (rs.next()) {
				OrganizationTL organizationTL = new OrganizationTL();
				organizationTL.setOrgId(rs.getInt("orgId"));
				organizationTL.setName(rs.getString("name"));
				organizationTL.setRegNo(rs.getInt("regNo"));
				organizationTL.setEmailId(rs.getString("emailId"));
				organizationTL.setAddress(rs.getString("address"));
				organizationTL.setMobaileNo(rs.getString("mobaileNo"));
				organizationTL.setContactPersonName(rs
						.getString("contactPersonName"));
				organizationTL.setStatus(rs.getString("status"));
				organizationTL.setCreatedON(rs.getDate("createdON"));
				organizationTL.setUpdatedON(rs.getDate("updatedON"));
				organizationTL.setPassword(rs.getString("password"));

				organization.add(organizationTL);

			}

		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeResultSet(rs);
			JDBCUtility.closeStatement(pst);
		}

		return null;
	}

	@Override
	public OrganizationTL getOrganization(String emailId, String password) {
		OrganizationTL organizationTL=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			pst=JDBCUtility.getConnection().prepareStatement("select orgId,name,regNo,emailId,address,mobaileNo,contactPersonName,status,createdON,updatedON,password from organizationtl where emailId=? and password=?");
			pst.setString(1,emailId);
			pst.setString(2,password);
			rs=pst.executeQuery();
			if(rs.next()){
				organizationTL = new OrganizationTL();
				organizationTL.setOrgId(rs.getInt("orgId"));
				organizationTL.setName(rs.getString("name"));
				organizationTL.setRegNo(rs.getInt("regNo"));
				organizationTL.setEmailId(rs.getString("emailId"));
				organizationTL.setAddress(rs.getString("address"));
				organizationTL.setMobaileNo(rs.getString("mobaileNo"));
				organizationTL.setContactPersonName(rs
						.getString("contactPersonName"));
				organizationTL.setStatus(rs.getString("status"));
				organizationTL.setCreatedON(rs.getDate("createdON"));
				organizationTL.setUpdatedON(rs.getDate("updatedON"));
				organizationTL.setPassword(rs.getString("password"));

				
			}
			
		}catch (SQLException sqle) {
			sqle.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			JDBCUtility.closeResultSet(rs);
			JDBCUtility.closeStatement(pst);
		}
		return organizationTL;
	}

}
