package com.global.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.global.dao.RequestEmpDAO;
import com.global.dao.model.RequestEmpTL;
import com.global.dao.util.JDBCUtility;

public class RequestEmpDAOImpl implements RequestEmpDAO {

	@Override
	public void insertRequestEmp(RequestEmpTL requestemp) {
		PreparedStatement pst = null;
		try {
			pst = JDBCUtility.getConnection().prepareStatement(
					"insert into RequestEmpTL (empId, status, reqid) values (?,?,?)");
			pst.setInt(1, requestemp.getEmpId());
			pst.setString(2, "Active");
			pst.setInt(3, requestemp.getReqId());
			pst.executeUpdate();

		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeStatement(pst);
		}

	}

	@Override
	public RequestEmpTL getRequestEmp(Integer reqId) {
		RequestEmpTL requestEmpTL = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			String sql = "select reqId,empId,status from RequestEmpTL where reqId=?";
			pst = JDBCUtility.getConnection().prepareStatement(sql);
			pst.setInt(1, reqId);
			rs = pst.executeQuery();
			if (rs.next()) {
				requestEmpTL = new RequestEmpTL();
				requestEmpTL.setReqId(rs.getInt("reqId"));
				requestEmpTL.setEmpId(rs.getInt("empId"));
				requestEmpTL.setStatus(rs.getString("status"));

			}

		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeResultSet(rs);
			JDBCUtility.closeStatement(pst);

		}

		return requestEmpTL;

	}

	@Override
	public List<RequestEmpTL> getRequestEmp() {
		List<RequestEmpTL> requestEmp=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="select reqId,empId,statusfrom RequestEmpTL";
			pst=JDBCUtility.getConnection().prepareStatement(sql);
			rs=pst.executeQuery();
			requestEmp=new ArrayList<RequestEmpTL>();
			while(rs.next()){
				RequestEmpTL requestEmpTL=new RequestEmpTL();
				requestEmpTL.setReqId(rs.getInt("reqId"));
				requestEmpTL.setEmpId(rs.getInt("empId"));
				requestEmpTL.setStatus(rs.getString("status"));
				
				requestEmp.add(requestEmpTL);
			}
			
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeResultSet(rs);
			JDBCUtility.closeStatement(pst);
		}
		
		
		return null;
	}

}
