package com.global.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.global.dao.AdminDAO;
import com.global.dao.model.AdminTL;
import com.global.dao.util.JDBCUtility;

public class AdminDAOImpl implements AdminDAO {
	
	public AdminTL getAdmin(String emailId,String password){
		AdminTL admin=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			pst=JDBCUtility.getConnection().prepareStatement("select adminId,name,emailId,mobaileNo,password,status from admintl where emailId=? and password=?");
			pst.setString(1,emailId);
			pst.setString(2,password);
			rs=pst.executeQuery();
			if(rs.next()){
				admin=new AdminTL();
				admin.setName(rs.getString("name"));
				admin.setEmailId("emailId");
				admin.setMobaileNo("mobaileNo");
				admin.setPassword("password");
				admin.setStatus("status");
				
			}
			
		}catch (SQLException sqle) {
			sqle.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			JDBCUtility.closeResultSet(rs);
			JDBCUtility.closeStatement(pst);
		}
		return admin;
	}

	@Override
	public AdminTL getAdmin(Integer adminId) {
		AdminTL adminTL = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			String sql = "select adminId,name,emailId,password from AdminTL where adminId=? ";
			pst = JDBCUtility.getConnection().prepareStatement(sql);
			pst.setInt(1, adminId);

			rs = pst.executeQuery();
			if (rs.next()) {
				adminTL = new AdminTL();
				adminTL.setAdminId(rs.getInt("adminId"));
				adminTL.setName(rs.getString("name"));
				adminTL.setEmailId(rs.getString("emailId"));
				adminTL.setPassword(rs.getString("password"));
			}

		} catch (SQLException sqle) {
			sqle.printStackTrace();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeResultSet(rs);
			JDBCUtility.closeStatement(pst);

		}

		return adminTL;
	}

}
