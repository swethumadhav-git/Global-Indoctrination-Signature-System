package com.global.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.global.dao.CourseDAO;
import com.global.dao.model.CourseTL;
import com.global.dao.util.JDBCUtility;

public class CourseDAOImpl implements CourseDAO {
	public void insertCourse(CourseTL course) {
		PreparedStatement pst = null;
		try {
			pst = JDBCUtility
					.getConnection()
					.prepareStatement(
							"insert into CourseTL(courseName,courseDescription,courseSyllabus,courseDuration,amount,discount,cateType) values (?,?,?,?,?,?,?)");

			pst.setString(1, course.getCourseName());
			pst.setString(2, course.getCourseDescription());
			pst.setString(3, course.getCourseSyllabus());
			pst.setString(4, course.getCourseDuration());
			pst.setFloat(5, course.getAmount());
			pst.setFloat(6, course.getDiscount());
			pst.setString(7, course.getCateType());
			pst.executeUpdate();

		} catch (SQLException sqle) {
			sqle.printStackTrace();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeStatement(pst);
		}

	}

	@Override
	public CourseTL getCourse(Integer courseId) {
		CourseTL courseTL = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			String sql = "select courseId,courseName,courseDescription,courseSyllabus,courseDuration,amount,discount,cateType from CourseTL where courseId=?";
			pst = JDBCUtility.getConnection().prepareStatement(sql);
			pst.setInt(1, courseId);

			rs = pst.executeQuery();
			if (rs.next()) {
				courseTL = new CourseTL();
				courseTL.setCourseId(rs.getInt("courseId"));
				courseTL.setCourseName(rs.getString("courseName"));
				courseTL.setCourseDescription(rs.getString("courseDescription"));
				courseTL.setCourseSyllabus(rs.getString("courseSyllabus"));
				courseTL.setCourseDuration(rs.getString("courseDuration"));
				courseTL.setAmount(rs.getFloat("amount"));
				courseTL.setDiscount(rs.getFloat("discount"));
				courseTL.setCateType(rs.getString("cateType"));

			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeResultSet(rs);
			JDBCUtility.closeStatement(pst);

		}

		return courseTL;

	}

	@Override
	public List<CourseTL> getCourses() {
		List<CourseTL> course=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="select courseId,courseName,courseDescription,courseSyllabus,courseDuration,amount,discount,cateType from CourseTL ";
			pst=JDBCUtility.getConnection().prepareStatement(sql);
			rs=pst.executeQuery();
			course=new ArrayList<CourseTL>();
			while(rs.next()){
				CourseTL courseTL=new CourseTL();
				courseTL.setCourseId(rs.getInt("courseId"));
				courseTL.setCourseName(rs.getString("courseName"));
				courseTL.setCourseDescription(rs.getString("courseDescription"));
				courseTL.setCourseSyllabus(rs.getString("courseSyllabus"));
				courseTL.setCourseDuration(rs.getString("courseDuration"));
				courseTL.setAmount(rs.getFloat("amount"));
				courseTL.setDiscount(rs.getFloat("discount"));
				courseTL.setCateType(rs.getString("cateType"));
				
				course.add(courseTL);
				
			}
			
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeResultSet(rs);
			JDBCUtility.closeStatement(pst);
		}
		
		
		return course;
	}

	@Override
	public List<CourseTL> getCourses(Integer empId) {
		List<CourseTL> course=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="select courseId,courseName,courseDescription,courseSyllabus,courseDuration,amount,discount,cateType from CourseTL where courseId in(select courseId from requesttl where requestId in(select reqeId from requestemptl where empId=?)) ";
			pst=JDBCUtility.getConnection().prepareStatement(sql);
			pst.setInt(1, empId);
			rs=pst.executeQuery();
			course=new ArrayList<CourseTL>();
			while(rs.next()){
				CourseTL courseTL=new CourseTL();
				courseTL.setCourseId(rs.getInt("courseId"));
				courseTL.setCourseName(rs.getString("courseName"));
				courseTL.setCourseDescription(rs.getString("courseDescription"));
				courseTL.setCourseSyllabus(rs.getString("courseSyllabus"));
				courseTL.setCourseDuration(rs.getString("courseDuration"));
				courseTL.setAmount(rs.getFloat("amount"));
				courseTL.setDiscount(rs.getFloat("discount"));
				courseTL.setCateType(rs.getString("cateType"));
				
				course.add(courseTL);
				
			}
			
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeResultSet(rs);
			JDBCUtility.closeStatement(pst);
		}
		
		
		return course;
	}
}
