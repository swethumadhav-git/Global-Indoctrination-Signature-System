package com.global.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.global.dao.RequestDAO;
import com.global.dao.model.RequestTL;
import com.global.dao.util.JDBCUtility;

public class RequestDAOImpl implements RequestDAO {

	@Override
	public Integer insertRequest(RequestTL request) {
		Integer reqId=0;
		PreparedStatement pst = null;
		ResultSet rs=null;
		try {
			pst = JDBCUtility
					.getConnection()
					.prepareStatement("select max(requestId) from requesttl");
			rs=pst.executeQuery();
			if(rs.next())
			{
				reqId=rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		reqId++;
		try {
			pst = JDBCUtility
					.getConnection()
					.prepareStatement(
							"insert into RequestTL (requestId, orgId, courseId, status, createdON) values (?,?,?,?,?)");
			pst.setInt(1, reqId);
			pst.setInt(2, request.getOrgId());
			pst.setInt(3, request.getCourseId());
			pst.setString(4,"Paid");
			pst.setDate(5, new java.sql.Date(new java.util.Date().getTime()));
			pst.executeUpdate();

		} catch (SQLException sqle) {
			sqle.printStackTrace();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeStatement(pst);
		}
		return reqId;

	}

	@Override
	public RequestTL getRequestTL(Integer requestId) {
		RequestTL requestTL = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			String sql = "select requestId,orgId,courseId,status,createdON from RequestTL where requestId=?";
			pst = JDBCUtility.getConnection().prepareStatement(sql);
			pst.setInt(1, requestId);
			rs = pst.executeQuery();
			if (rs.next()) {
				requestTL = new RequestTL();
				requestTL.setRequestId(rs.getInt("requestId"));
				requestTL.setOrgId(rs.getInt("orgId"));
				requestTL.setCourseId(rs.getInt("courseId"));
				requestTL.setStatus(rs.getString("status"));
				requestTL.setCreatedON(rs.getDate("createdON"));

			}

		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeResultSet(rs);
			JDBCUtility.closeStatement(pst);
		}

		return requestTL;
	}

	@Override
	public List<RequestTL> getRequest() {
		List<RequestTL> request=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			String sql="select requestId,orgId,courseId,status,createdON from RequestTL";
			pst=JDBCUtility.getConnection().prepareStatement(sql);
			rs=pst.executeQuery();
			request=new ArrayList<RequestTL>();
			while(rs.next()){
				RequestTL requestTL=new RequestTL();
				requestTL.setRequestId(rs.getInt("requestId"));
				requestTL.setOrgId(rs.getInt("orgId"));
				requestTL.setCourseId(rs.getInt("courseId"));
				requestTL.setStatus(rs.getString("status"));
				requestTL.setCreatedON(rs.getDate("createdON"));
				
				request.add(requestTL);
				
			}
			
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeResultSet(rs);
			JDBCUtility.closeStatement(pst);
		}
		
		
		return null;
	}

}
