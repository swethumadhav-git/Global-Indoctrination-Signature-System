package com.global.dao;

import com.global.dao.model.AdminTL;

public interface AdminDAO {
	
	public AdminTL getAdmin(String emailId, String password);//login 

	public AdminTL getAdmin(Integer adminId);

}
