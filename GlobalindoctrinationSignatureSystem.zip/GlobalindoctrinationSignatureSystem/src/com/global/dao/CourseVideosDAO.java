package com.global.dao;

import java.util.List;

import com.global.dao.model.CourseVideosTL;

public interface CourseVideosDAO {
	public void insertCourseVideo(CourseVideosTL cvideo);

	public CourseVideosTL getCourseVideo(Integer coursevId);

	public List<CourseVideosTL> getCourseVideos();
	public List<CourseVideosTL> getCourseVideos(Integer courseId);

}
