package com.global.dao;

import java.util.List;

import com.global.dao.model.OrganizationTL;

public interface OrganizationDAO {
	public void insertOrganization(OrganizationTL organization);

	public OrganizationTL getOrganization(Integer orgId);

	public List<OrganizationTL> getOrganization();
	
	public OrganizationTL getOrganization(String emailId,String password);//org loginfaculty.html
}
