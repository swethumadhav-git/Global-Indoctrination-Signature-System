package com.global.dao;

import java.util.List;

import com.global.dao.model.RequestEmpTL;

public interface RequestEmpDAO {
	public void insertRequestEmp(RequestEmpTL requestemp);
	
	public RequestEmpTL getRequestEmp(Integer reqId);
	
	public List<RequestEmpTL> getRequestEmp();

}
