package com.global.dao;

import java.util.List;

import com.global.dao.model.EmpTL;

public interface EmpDAO {
	public void insertEmp(EmpTL emp);

	public EmpTL getEmp(Integer empId);
	
	public List<EmpTL> getEmp();
	public List<EmpTL> getEmps(Integer orgId);
	public EmpTL getEmp(String emailId,String password);
	
	

}
