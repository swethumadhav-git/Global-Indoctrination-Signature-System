package com.global.dao;

import java.util.List;

import com.global.dao.model.CourseTL;

public interface CourseDAO {
	public void insertCourse(CourseTL course);	//inserting course

	public CourseTL getCourse(Integer courseId);

	public List<CourseTL> getCourses();
	public List<CourseTL> getCourses(Integer empId);

}
