package com.global.dao;

import java.util.List;

import com.global.dao.model.RequestTL;

public interface RequestDAO {
	public Integer insertRequest(RequestTL request);

	public RequestTL getRequestTL(Integer requestId);
	
	public List<RequestTL> getRequest();

}
