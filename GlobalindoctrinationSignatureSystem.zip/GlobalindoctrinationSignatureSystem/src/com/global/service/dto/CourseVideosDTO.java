package com.global.service.dto;

public class CourseVideosDTO {
	private Integer coursevId;
	private Integer courseId;
	private String videoName;

	public Integer getCoursevId() {
		return coursevId;
	}

	public void setCoursevId(Integer coursevId) {
		this.coursevId = coursevId;
	}

	public Integer getCourseId() {
		return courseId;
	}

	public void setCourseId(Integer courseId) {
		this.courseId = courseId;
	}

	public String getVideoName() {
		return videoName;
	}

	public void setVideoName(String videoName) {
		this.videoName = videoName;
	}

}
