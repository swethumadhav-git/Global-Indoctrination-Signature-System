package com.global.service.dto;

import java.util.Date;

public class OrganizationDTO {
	private Integer orgId;
	private String name;
	private Integer regNo;
	private String emailId;
	private String address;
	private String mobaileNo;
	private String contactPersonName;
	private String status;
	private Date createdON;
	private Date updatedON;
	private String password;

	public Integer getOrgId() {
		return orgId;
	}

	public void setOrgId(Integer orgId) {
		this.orgId = orgId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getRegNo() {
		return regNo;
	}

	public void setRegNo(Integer regNo) {
		this.regNo = regNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getMobaileNo() {
		return mobaileNo;
	}

	public void setMobaileNo(String mobaileNo) {
		this.mobaileNo = mobaileNo;
	}

	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getCreatedON() {
		return createdON;
	}

	public void setCreatedON(Date createdON) {
		this.createdON = createdON;
	}

	public Date getUpdatedON() {
		return updatedON;
	}

	public void setUpdatedON(Date updatedON) {
		this.updatedON = updatedON;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
