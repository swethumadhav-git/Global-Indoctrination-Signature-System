package com.global.service;

import com.global.service.dto.AdminDTO;

public interface AdminService {

	public AdminDTO getAdmin(String emailId, String password);//login 
	
	public AdminDTO loadAdmin(Integer adminId);

}
