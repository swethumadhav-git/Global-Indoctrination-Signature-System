package com.global.service;

import java.util.List;

import com.global.service.dto.OrganizationDTO;

public interface OrganizationService {
	public OrganizationDTO loadOrganization(Integer orgId);

	public void saveOrganization(OrganizationDTO organizationDTO);
	
	public List<OrganizationDTO> loadOrganization();
	
	public OrganizationDTO getOrganization(String emailId,String password);
	

}
