package com.global.service;

import java.util.List;

import com.global.service.dto.RequestDTO;

public interface RequestService {
public RequestDTO loadRequest(Integer reqId);
	
	public Integer saveRequest(RequestDTO requestDTO);
	
	public List<RequestDTO> loadRequest();
	

}
