package com.global.service;


import java.util.List;

import com.global.service.dto.RequestEmpDTO;

public interface RequestEmpService {
	public RequestEmpDTO loadRequestEmp(Integer reqId);
	
	public void saveRequestEmp(RequestEmpDTO requestEmpDTO);
	
	public List<RequestEmpDTO> loadRequestEmp();
	

}
