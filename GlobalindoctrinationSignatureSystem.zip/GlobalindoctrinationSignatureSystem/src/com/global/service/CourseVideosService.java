package com.global.service;

import java.util.List;

import com.global.service.dto.CourseVideosDTO;

public interface CourseVideosService {
	public CourseVideosDTO loadCourseVideo(Integer coursevId);
	
	public void saveCourseVideo(CourseVideosDTO courseVideosDTO);
	
	public List<CourseVideosDTO> loadCourseVideos();
	public List<CourseVideosDTO> loadCourseVideos(Integer courseId);

}
