package com.global.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import com.global.dao.EmpDAO;
import com.global.dao.impl.EmpDAOImpl;
import com.global.dao.model.EmpTL;
import com.global.service.EmpService;
import com.global.service.dto.EmpDTO;

public class EmpServiceImpl implements EmpService {
	private EmpDAO empDAO;

	public EmpServiceImpl() {
		empDAO =new  EmpDAOImpl();
	}

	public EmpDTO convertTLtoDTO(EmpTL empTL) {
		EmpDTO empDTO = new EmpDTO();
		empDTO.setEmpId(empTL.getEmpId());
		empDTO.setOrgId(empTL.getOrgId());
		empDTO.setEmpName(empTL.getEmpName());
		empDTO.setAddress(empTL.getAddress());
		empDTO.setEmpCode(empTL.getEmpCode());
		empDTO.setEmailId(empTL.getEmailId());
		empDTO.setMobaileNo(empTL.getMobaileNo());
		
		return empDTO;
	}

	public EmpTL convertDTOtoTL(EmpDTO empDTO) {
		EmpTL empTL = new EmpTL();
		empTL.setEmpId(empDTO.getEmpId());
		empTL.setOrgId(empDTO.getOrgId());
		empTL.setEmpName(empDTO.getEmpName());
		empTL.setAddress(empDTO.getAddress());
		empTL.setEmpCode(empDTO.getEmpCode());
		empTL.setEmailId(empDTO.getEmailId());
		empTL.setMobaileNo(empDTO.getMobaileNo());
		
		return empTL;
	}

	@Override
	public EmpDTO loadEmp(Integer empId) {
		EmpDTO empDTO = null;
		EmpTL empTL = empDAO.getEmp(empId);
		if (empTL != null) {
			empDTO = convertTLtoDTO(empTL);
		}

		return empDTO;
	}

	@Override
	public void saveEmp(EmpDTO empDTO) {
		if (empDTO != null) {
			EmpTL empTL = convertDTOtoTL(empDTO);
			empDAO.insertEmp(empTL);
		}

	}

	@Override
	public List<EmpDTO> loadEmp() {
		List<EmpDTO> empDTO = null;
		List<EmpTL> emps = empDAO.getEmp();
		if (emps != null) {
			empDTO = new ArrayList<EmpDTO>();
			ListIterator<EmpTL> li = emps.listIterator();
			while (li.hasNext()) {
				EmpTL emp = li.next();
				EmpDTO empsDTO = convertTLtoDTO(emp);
				empDTO.add(empsDTO);
			}

		}

		return empDTO;
	}

	@Override
	public List<EmpDTO> loadEmps(Integer orgId) {
		List<EmpDTO> empDTO = null;
		List<EmpTL> emps = empDAO.getEmps(orgId);
		if (emps != null) {
			empDTO = new ArrayList<EmpDTO>();
			ListIterator<EmpTL> li = emps.listIterator();
			while (li.hasNext()) {
				EmpTL emp = li.next();
				EmpDTO empsDTO = convertTLtoDTO(emp);
				empDTO.add(empsDTO);
			}

		}

		return empDTO;
		
	}

	@Override
	public EmpDTO loadEmp(String emailId, String password) {
		
		EmpDTO empDTO = null;
		EmpTL empTL = empDAO.getEmp(emailId,password);
		if (empTL != null) {
			empDTO = convertTLtoDTO(empTL);
		}

		return empDTO;
	}

}
