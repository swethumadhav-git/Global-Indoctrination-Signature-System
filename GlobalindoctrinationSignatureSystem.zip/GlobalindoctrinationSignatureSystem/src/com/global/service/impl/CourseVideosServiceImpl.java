package com.global.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import com.global.dao.CourseVideosDAO;
import com.global.dao.impl.CourseVideosDAOImpl;
import com.global.dao.model.CourseVideosTL;
import com.global.service.CourseVideosService;
import com.global.service.dto.CourseVideosDTO;

public class CourseVideosServiceImpl implements CourseVideosService {
	private CourseVideosDAO courseVideosDAO;

	public CourseVideosServiceImpl() {
		courseVideosDAO=new CourseVideosDAOImpl();
	}

	public CourseVideosDTO convertTLtoDTO(CourseVideosTL courseVideosTL) {
		CourseVideosDTO courseVideosDTO = new CourseVideosDTO();
		courseVideosDTO.setCoursevId(courseVideosTL.getCoursevId());
		courseVideosDTO.setCourseId(courseVideosTL.getCourseId());
		courseVideosDTO.setVideoName(courseVideosTL.getVideoName());

		return courseVideosDTO;
	}

	public CourseVideosTL convertDTOtoTL(CourseVideosDTO courseVideosDTO) {
		CourseVideosTL courseVideosTL = new CourseVideosTL();
		courseVideosTL.setCoursevId(courseVideosDTO.getCoursevId());
		courseVideosTL.setCourseId(courseVideosDTO.getCourseId());
		courseVideosTL.setVideoName(courseVideosDTO.getVideoName());

		return courseVideosTL;

	}

	@Override
	public CourseVideosDTO loadCourseVideo(Integer coursevId) {
		CourseVideosDTO courseVideosDTO = null;
		CourseVideosTL courseVideosTL = courseVideosDAO
				.getCourseVideo(coursevId);
		if (courseVideosTL != null) {
			courseVideosDTO = convertTLtoDTO(courseVideosTL);
		}

		return courseVideosDTO;
	}

	@Override
	public void saveCourseVideo(CourseVideosDTO courseVideosDTO) {
		if (courseVideosDTO != null) {
			CourseVideosTL courseVideosTL = convertDTOtoTL(courseVideosDTO);
			courseVideosDAO.insertCourseVideo(courseVideosTL);

		}

	}

	@Override
	public List<CourseVideosDTO> loadCourseVideos() {
		List<CourseVideosDTO> courseVideosDTO = null;
		List<CourseVideosTL> courseVideos = courseVideosDAO.getCourseVideos();
		if (courseVideos != null) {
			courseVideosDTO = new ArrayList<CourseVideosDTO>();
			ListIterator<CourseVideosTL> li = courseVideos.listIterator();
			while (li.hasNext()) {
				CourseVideosTL courseVideo = li.next();
				CourseVideosDTO coursesVideosDTO = convertTLtoDTO(courseVideo);
				courseVideosDTO.add(coursesVideosDTO);
			}

		}

		return courseVideosDTO;
	}
	
	public List<CourseVideosDTO> loadCourseVideos(Integer courseId) {
		List<CourseVideosDTO> courseVideosDTO = null;
		List<CourseVideosTL> courseVideos = courseVideosDAO.getCourseVideos(courseId);
		if (courseVideos != null) {
			courseVideosDTO = new ArrayList<CourseVideosDTO>();
			ListIterator<CourseVideosTL> li = courseVideos.listIterator();
			while (li.hasNext()) {
				CourseVideosTL courseVideo = li.next();
				CourseVideosDTO coursesVideosDTO = convertTLtoDTO(courseVideo);
				courseVideosDTO.add(coursesVideosDTO);
			}

		}

		return courseVideosDTO;
	}

}
