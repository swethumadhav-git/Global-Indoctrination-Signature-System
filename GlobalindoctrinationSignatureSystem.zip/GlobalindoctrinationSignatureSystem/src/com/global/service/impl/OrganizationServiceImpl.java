package com.global.service.impl;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import com.global.dao.OrganizationDAO;
import com.global.dao.impl.OrganizationDAOImpl;
import com.global.dao.model.OrganizationTL;
import com.global.service.OrganizationService;
import com.global.service.dto.OrganizationDTO;

public class OrganizationServiceImpl implements OrganizationService {
	private OrganizationDAO organizationDAO;

	public OrganizationServiceImpl() {
		organizationDAO = new OrganizationDAOImpl();
	}

	public OrganizationDTO convertTLtoDTo(OrganizationTL organizationTL) {
		OrganizationDTO organizationDTO = new OrganizationDTO();
		organizationDTO.setOrgId(organizationTL.getOrgId());
		organizationDTO.setName(organizationTL.getName());
		organizationDTO.setRegNo(organizationTL.getRegNo());
		organizationDTO.setEmailId(organizationTL.getEmailId());
		organizationDTO.setAddress(organizationTL.getAddress());
		organizationDTO.setMobaileNo(organizationTL.getMobaileNo());
		organizationDTO.setContactPersonName(organizationTL
				.getContactPersonName());
		organizationDTO.setCreatedON(organizationTL.getCreatedON());
		organizationDTO.setUpdatedON(organizationTL.getUpdatedON());
		organizationDTO.setStatus(organizationTL.getStatus());
		organizationDTO.setPassword(organizationTL.getPassword());

		return organizationDTO;
	}

	public OrganizationTL convertDTOtoTL(OrganizationDTO organizationDTO) {
		OrganizationTL organizationTL = new OrganizationTL();
		organizationTL.setOrgId(organizationDTO.getOrgId());
		organizationTL.setName(organizationDTO.getName());
		organizationTL.setRegNo(organizationDTO.getRegNo());
		organizationTL.setEmailId(organizationDTO.getEmailId());
		organizationTL.setAddress(organizationDTO.getAddress());
		organizationTL.setMobaileNo(organizationDTO.getMobaileNo());
		organizationTL.setContactPersonName(organizationDTO
				.getContactPersonName());
		organizationTL.setStatus(organizationDTO.getStatus());
		organizationTL.setCreatedON(new Date(organizationDTO.getCreatedON()
				.getTime()));
		organizationTL.setUpdatedON(new Date(organizationDTO.getUpdatedON()
				.getTime()));
		organizationTL.setPassword(organizationDTO.getPassword());

		return organizationTL;
	}

	@Override
	public OrganizationDTO loadOrganization(Integer orgId) {
		OrganizationDTO organizationDTO = null;
		OrganizationTL organizationTL = organizationDAO.getOrganization(orgId);
		if (organizationTL != null) {
			organizationDTO = convertTLtoDTo(organizationTL);
		}

		return organizationDTO;
	}

	@Override
	public void saveOrganization(OrganizationDTO organizationDTO) {
		if (organizationDTO != null) {
			OrganizationTL organizationTL = convertDTOtoTL(organizationDTO);
			organizationDAO.insertOrganization(organizationTL);
		}

	}

	@Override
	public List<OrganizationDTO> loadOrganization() {
		List<OrganizationDTO> organizationDTO = null;
		List<OrganizationTL> organizations = organizationDAO.getOrganization();
		if (organizations != null) {
			organizationDTO = new ArrayList<OrganizationDTO>();
			ListIterator<OrganizationTL> li = organizations.listIterator();
			while (li.hasNext()) {
				OrganizationTL organizationTL = li.next();
				OrganizationDTO organizationsDTO = convertTLtoDTo(organizationTL);
				organizationDTO.add(organizationsDTO);
			}

		}

		return organizationDTO;
	}

	@Override
	public OrganizationDTO getOrganization(String emailId, String password) {
		OrganizationDTO organizationDTO = null;
		OrganizationTL organizationTL = organizationDAO.getOrganization(
				emailId, password);
		if (organizationTL != null) {
			organizationDTO = convertTLtoDTo(organizationTL);

		}

		return organizationDTO;
	}

}
