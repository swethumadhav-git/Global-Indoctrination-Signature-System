 package com.global.service.impl;

import com.global.dao.AdminDAO;
import com.global.dao.impl.AdminDAOImpl;
import com.global.dao.model.AdminTL;
import com.global.service.AdminService;
import com.global.service.dto.AdminDTO;

public class AdminServiceImpl implements AdminService {
	private AdminDAO adminDAO;

	public AdminServiceImpl() {
		adminDAO=new AdminDAOImpl();
	}

	public AdminDTO convertTLtoDTO(AdminTL adminTL) {
		AdminDTO adminDTO = new AdminDTO();
		adminDTO.setAdminId(adminTL.getAdminId());
		adminDTO.setName(adminTL.getName());
		adminDTO.setEmailId(adminTL.getEmailId());
		adminDTO.setPassword(adminTL.getPassword());

		return adminDTO;
	}

	public AdminTL convertDTOtoTL(AdminDTO adminDTO) {
		AdminTL adminTL = new AdminTL();
		adminTL.setAdminId(adminDTO.getAdminId());
		adminTL.setName(adminDTO.getName());
		adminTL.setEmailId(adminDTO.getEmailId());
		adminTL.setPassword(adminDTO.getPassword());

		return adminTL;

	}
	
	@Override
	public AdminDTO getAdmin(String emailId, String password) {
		AdminDTO adminDTO=null;
		AdminTL adminTL=adminDAO.getAdmin(emailId, password);
		if(adminTL!=null){
			adminDTO=convertTLtoDTO(adminTL);
		}
		return adminDTO;
	}


	public AdminDTO loadAdmin(Integer adminId) {
		AdminDTO adminDTO = null;
		AdminTL adminTL = adminDAO.getAdmin(adminId);
		if (adminTL != null) {
			adminDTO = convertTLtoDTO(adminTL);
		}

		return adminDTO;
	}

	
}
