package com.global.service.impl;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import com.global.dao.RequestDAO;
import com.global.dao.impl.RequestDAOImpl;
import com.global.dao.model.RequestTL;
import com.global.service.RequestService;
import com.global.service.dto.RequestDTO;

public class RequestServiceImpl implements RequestService  {
	private RequestDAO requestDAO;

	public RequestServiceImpl() {
		requestDAO =new RequestDAOImpl();
	}

	public RequestDTO convertTLtoDTO(RequestTL requestTL) {
		RequestDTO requestDTO = new RequestDTO();
		requestDTO.setRequestId(requestTL.getRequestId());
		requestDTO.setOrgId(requestTL.getOrgId());
		requestDTO.setCourseId(requestTL.getCourseId());
		requestDTO.setStatus(requestTL.getStatus());
		requestDTO.setCreatedON(requestTL.getCreatedON());

		return requestDTO;

	}

	public RequestTL convertDTOtoTL(RequestDTO requestDTO) {
		RequestTL requestTL = new RequestTL();
		requestTL.setRequestId(requestDTO.getRequestId());
		requestTL.setOrgId(requestDTO.getOrgId());
		requestTL.setCourseId(requestDTO.getCourseId());
		requestTL.setStatus(requestDTO.getStatus());
		requestTL.setCreatedON(new Date(requestDTO.getCreatedON().getTime()));

		return requestTL;
	}

	@Override
	public RequestDTO loadRequest(Integer requestId) {
		RequestDTO requestDTO = null;
		RequestTL requestTL = requestDAO.getRequestTL(requestId);
		if (requestTL != null) {
			requestDTO = convertTLtoDTO(requestTL);
		}

		return requestDTO;
	}

	@Override
	public Integer saveRequest(RequestDTO requestDTO) {
		Integer reqId=0;
		if (requestDTO != null) {
			RequestTL requestTL = convertDTOtoTL(requestDTO);
			reqId=requestDAO.insertRequest(requestTL);
		}
		return reqId;

	}

	@Override
	public List<RequestDTO> loadRequest() {
		List<RequestDTO> requestDTO = null;
		List<RequestTL> requests = requestDAO.getRequest();
		if (requests != null) {
			requestDTO = new ArrayList<RequestDTO>();
			ListIterator<RequestTL> li = requests.listIterator();
			while (li.hasNext()) {
				RequestTL requestTL = li.next();
				RequestDTO requestsDTO = convertTLtoDTO(requestTL);
				requestDTO.add(requestsDTO);
			}

		}

		return requestDTO;
	}
}
