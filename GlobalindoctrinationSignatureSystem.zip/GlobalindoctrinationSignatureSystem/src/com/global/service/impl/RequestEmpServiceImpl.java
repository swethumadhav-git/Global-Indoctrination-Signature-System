package com.global.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import com.global.dao.RequestEmpDAO;
import com.global.dao.impl.RequestEmpDAOImpl;
import com.global.dao.model.RequestEmpTL;
import com.global.service.RequestEmpService;
import com.global.service.dto.RequestEmpDTO;

public class RequestEmpServiceImpl implements RequestEmpService {
	private RequestEmpDAO requestEmpDAO;

	public RequestEmpServiceImpl() {
		requestEmpDAO = new RequestEmpDAOImpl();
	}

	public RequestEmpDTO convertTLtoDTO(RequestEmpTL requestEmpTL) {
		RequestEmpDTO requestEmpDTO = new RequestEmpDTO();
		requestEmpDTO.setReqId(requestEmpTL.getReqId());
		requestEmpDTO.setEmpId(requestEmpTL.getEmpId());
		requestEmpDTO.setStatus(requestEmpTL.getStatus());

		return requestEmpDTO;
	}

	public RequestEmpTL convertDTOtoTL(RequestEmpDTO requestEmpDTO) {
		RequestEmpTL requestEmpTL = new RequestEmpTL();
		requestEmpTL.setReqId(requestEmpDTO.getReqId());
		requestEmpTL.setEmpId(requestEmpDTO.getEmpId());
		requestEmpTL.setStatus(requestEmpDTO.getStatus());

		return requestEmpTL;
	}

	@Override
	public RequestEmpDTO loadRequestEmp(Integer reqId) {
		RequestEmpDTO requestEmpDTO = null;
		RequestEmpTL requestEmpTL = requestEmpDAO.getRequestEmp(reqId);
		if (requestEmpTL != null) {
			requestEmpDTO = convertTLtoDTO(requestEmpTL);
		}
		return requestEmpDTO;
	}

	@Override
	public void saveRequestEmp(RequestEmpDTO requestEmpDTO) {
		if (requestEmpDTO != null) {
			RequestEmpTL requestEmpTL = convertDTOtoTL(requestEmpDTO);
			requestEmpDAO.insertRequestEmp(requestEmpTL);
		}

	}

	@Override
	public List<RequestEmpDTO> loadRequestEmp() {
		List<RequestEmpDTO> requestEmpDTO = null;
		List<RequestEmpTL> requestEmps = requestEmpDAO.getRequestEmp();
		if (requestEmps != null) {
			requestEmpDTO = new ArrayList<RequestEmpDTO>();
			ListIterator<RequestEmpTL> li = requestEmps.listIterator();
			while (li.hasNext()) {
				RequestEmpTL requestEmpTL = li.next();
				RequestEmpDTO requestEmpsDTO = convertTLtoDTO(requestEmpTL);
				requestEmpDTO.add(requestEmpsDTO);
			}

		}

		return requestEmpDTO;
	}

}
