package com.global.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import com.global.dao.CourseDAO;
import com.global.dao.impl.CourseDAOImpl;
import com.global.dao.model.CourseTL;
import com.global.service.CourseService;
import com.global.service.dto.CourseDTO;

public class CourseServiceImpl implements CourseService {
	private CourseDAO courseDAO;

	public CourseServiceImpl() {
		courseDAO =new CourseDAOImpl();
	}

	public CourseDTO convertTLtoDTO(CourseTL courseTL) {
		CourseDTO courseDTO = new CourseDTO();
		courseDTO.setCourseId(courseTL.getCourseId());
		courseDTO.setCourseName(courseTL.getCourseName());
		courseDTO.setCourseDescription(courseTL.getCourseDescription());
		courseDTO.setCourseSyllabus(courseTL.getCourseSyllabus());
		courseDTO.setCourseDuration(courseTL.getCourseDuration());
		courseDTO.setAmount(courseTL.getAmount());
		courseDTO.setDiscount(courseTL.getDiscount());
		courseDTO.setCateType(courseTL.getCateType());

		return courseDTO;
	}

	public CourseTL convertDTOtoTL(CourseDTO courseDTO) {
		CourseTL courseTL = new CourseTL();
		courseTL.setCourseId(courseDTO.getCourseId());
		courseTL.setCourseName(courseDTO.getCourseName());
		courseTL.setCourseDescription(courseDTO.getCourseDescription());
		courseTL.setCourseSyllabus(courseDTO.getCourseSyllabus());
		courseTL.setCourseDuration(courseDTO.getCourseDuration());
		courseTL.setAmount(courseDTO.getAmount());
		courseTL.setDiscount(courseDTO.getDiscount());
		courseTL.setCateType(courseDTO.getCateType());

		return courseTL;
	}

	@Override
	public CourseDTO loadCourse(Integer courseId) {
		CourseDTO courseDTO = null;
		CourseTL courseTL = courseDAO.getCourse(courseId);
		if (courseTL != null) {
			courseDTO = convertTLtoDTO(courseTL);
		}

		return courseDTO;
	}

	@Override
	public void saveCourse(CourseDTO courseDTO) {
		if (courseDTO != null) {
			CourseTL courseTL = convertDTOtoTL(courseDTO);
			courseDAO.insertCourse(courseTL);
		}

	}

	@Override
	public List<CourseDTO> loadCourses() {
		List<CourseDTO> courseDTO = null;
		List<CourseTL> courses = courseDAO.getCourses();
		if (courses != null) {
			courseDTO = new ArrayList<CourseDTO>();
			ListIterator<CourseTL> li = courses.listIterator();
			while (li.hasNext()) {
				CourseTL course = li.next();
				CourseDTO coursesDTO = convertTLtoDTO(course);
				courseDTO.add(coursesDTO);
			}

		}

		return courseDTO;
	}
	public List<CourseDTO> loadCourses(Integer empId) {
		List<CourseDTO> courseDTO = null;
		List<CourseTL> courses = courseDAO.getCourses(empId);
		if (courses != null) {
			courseDTO = new ArrayList<CourseDTO>();
			ListIterator<CourseTL> li = courses.listIterator();
			while (li.hasNext()) {
				CourseTL course = li.next();
				CourseDTO coursesDTO = convertTLtoDTO(course);
				courseDTO.add(coursesDTO);
			}

		}

		return courseDTO;
	}

}
