package com.global.service;

import java.util.List;

import com.global.service.dto.CourseDTO;

public interface CourseService {
	
	public void saveCourse(CourseDTO courseDTO);
	
	public CourseDTO loadCourse(Integer courseId);

	
	
	public List<CourseDTO> loadCourses();
	public List<CourseDTO> loadCourses(Integer empId);

}
