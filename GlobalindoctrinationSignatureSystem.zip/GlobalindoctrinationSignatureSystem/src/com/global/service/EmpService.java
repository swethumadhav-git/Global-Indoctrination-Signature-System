package com.global.service;

import java.util.List;


import com.global.service.dto.EmpDTO;

public interface EmpService {
	public EmpDTO loadEmp(Integer empId);
	
	public void saveEmp(EmpDTO empDTO);
	
	public List<EmpDTO> loadEmp();
	
	public List<EmpDTO> loadEmps(Integer orgId);
	public EmpDTO loadEmp(String emailId,String password);
	

}
